import csv
from pathlib import Path

import matplotlib.pyplot as plt

# 你的六组实验结果所在位置
RESULTS_DIR = Path.home() / "Desktop" / "results" / "results"

# 图片会统一输出到这里，不会改动原始实验结果
OUTPUT_DIR = Path.home() / "Desktop" / "results" / "individual_plots"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 文件夹名、图标题、曲线颜色
RUNS = [
    ("adamw-default", "AdamW (lr = 0.0003)", "#1f77b4"),
    ("adamw-other",   "AdamW (lr = 0.00015)", "#1f77b4"),
    ("muon-default",  "Muon (lr = 0.01)", "#ff7f0e"),
    ("muon-other",    "Muon (lr = 0.005)", "#ff7f0e"),
    ("sgdm-default",  "SGDM (lr = 0.1)", "#2ca02c"),
    ("sgdm-other",    "SGDM (lr = 0.05)", "#2ca02c"),
]

for run_folder, title, train_color in RUNS:
    metrics_path = RESULTS_DIR / run_folder / "metrics.csv"

    if not metrics_path.exists():
        print(f"Skipped: {metrics_path} not found")
        continue

    tokens = []
    train_loss = []
    val_loss = []

    with open(metrics_path, newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            tokens.append(float(row["tokens"]) / 1_000_000)  # 转为百万 tokens
            train_loss.append(float(row["train_loss"]))
            val_loss.append(float(row["val_loss"]))

    plt.figure(figsize=(9, 6))

    plt.plot(
        tokens,
        train_loss,
        marker="o",
        linewidth=2,
        markersize=5,
        color=train_color,
        label="Training Loss",
    )

    plt.plot(
        tokens,
        val_loss,
        marker="s",
        linewidth=2,
        markersize=5,
        color="#d62728",
        label="Validation Loss",
    )

    plt.title(title, fontsize=15, fontweight="bold")
    plt.xlabel("Training Prediction Tokens (millions)", fontsize=12)
    plt.ylabel("Cross-Entropy Loss", fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()

    output_path = OUTPUT_DIR / f"{run_folder}_individual_plot.png"
    plt.savefig(output_path, dpi=300)
    plt.close()

    print(f"Saved: {output_path}")

print("\nDone. All six individual plots are in:")
print(OUTPUT_DIR)